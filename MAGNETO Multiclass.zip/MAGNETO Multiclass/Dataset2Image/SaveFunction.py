#!/usr/bin/env python3

import numpy as np
import pickle
import csv
import os

def saveImages(params, images, fileName):
	f = open(fileName)
	np.save(f, images)
	f.close()