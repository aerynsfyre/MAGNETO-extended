# Code from Dunmore et al., 2023, "MAGNETO and DeepInsight: Extended Image Translation with Semantic Relationships for Classifying Attack Data with Convolutional Neural Networks".
# Additional code from: 
# Andresini et al., 2021, "GAN augmentation to deal with imbalance in imaging-based intrusion detection" doi: 10.1016/j.future.2021.04.017
# Sharma et al., 2019, "DeepInsight: A methodology to transform a non-image data to an image for convolution neural network architecture" doi: 10.1038/s41598-019-47765-6.
# Please cite these papers if you are going to use any part of this code in further research.

import os
import pickle
import pandas as pd
import csv
import numpy as np
import logging
from imblearn.over_sampling import SMOTE, ADASYN
from lib import train

import sys
from datetime import datetime

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# In original MAGNETO paper, Andresini et al., set Max Size to 10x10, evals to 100 and epochs to 2.
# If class_mode is set to binary, it will replace all labels such that Benign/Normal is 0 and all other are 1.
# If class_mode is set to multi, it will operate over all the attack types in the files.
# Classifier types are RF (Random Fores), DT (Decision Tree), CNN2 (2D Convolutional Neural Network), and CNN_Nature (Basic Convolutional Neural Network.)
# The CNN2 and CNN_Nature classifiers are those implemented by Andresini et al. They have only been modified to allow the number of outputs to change with the dataset.

# Parameters to change for operation.
param = {"Max_A_Size": 10, "Max_B_Size": 10, "Dynamic_Size": False, 'Metod': 'tSNE', "ValidRatio": 0.1, "seed": 180,
         "dir": "", "Mode": "CNN_Nature",  # Mode : CNN_Nature, CNN2, SVM, DT, RF,  Inception (images must be 75x75 or greater for this mode)
         "LoadFromPickle": True, "mutual_info": False,  # Mean or MI
         "hyper_opt_evals": 100, "epoch": 2, "No_0_MI": False,  # True -> Removing 0 MI Features
         "autoencoder": False, "cut": None, "enhanced_dataset": "None",  # gan, smote, adasyn, ""None""
        "save_images": False, "load_images": True, "full_dir": "/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO Dataset/", "class_mode": "multi", "exclude":-1, "activation_function":"softmax", #sigmoid (binary), or softmax, (multi)
        "tuning": "hyperopt" #hyperopt, skopt, optima
         }

dataset = 6 # change dataset
image_size = param["Max_A_Size"]
if dataset == 1: 
    param["classif_label"] = 'Label' #100% of dataset used. (CICDDoS 2019)
    param["attack_label"] = 0
    param["outputs"] = 8
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 2:
    param["classif_label"] = 'Attack Type' #100% of dataset used. (5G-NIDD)
    param["attack_label"] = 1.0
    param["outputs"] = 9
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 3:
    param["classif_label"] = 'Label' #100% of dataset used. (BoT-IoT)
    param["attack_label"] = 1.0
    param["outputs"] = 15
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 4:
    param["classif_label"] = 'Label' #10% of full dataset as per Andresini et al.
    param["attack_label"] = 13
    param["outputs"] = 23
    param["dataset_name"] = "UNSW/"
    param["full_dir"] = "/MAGNETO datasets/"
elif dataset == 5:
    param["classif_label"] = "Label" #10% of full dataset as per Andresini et al.
    param["attack_label"] = 11
    param["dataset_name"] = "KDD Source/kddcup.data_10_percent/"
    param["full_dir"] = "/MAGNETO datasets/"
elif dataset == 6:
    param["classif_label"] = "Label" #10% of full dataset as per Andresini et al.
    param["attack_label"] = 5
    param["dataset_name"] = "CICIDS17/"
    param["full_dir"] = "/MAGNETO datasets/"
    param["exclude"] = 10 # Unknown type of traffic. Remove it from the sets.
elif dataset == 7:
    param["classif_label"] = 'Label' #10% of full dataset as per Andresini et al.
    param["attack_label"] = 9
    param["outputs"] = 18
    param["dataset_name"] = "NSL-KDD/"
    param["full_dir"] = "/MAGNETO datasets/"
date_stamp = str(datetime.now())
start_time = datetime.now()
forbidden_characters = [':','/',"\\",'?','<','>','|',"...",".."]
for i in forbidden_characters:
    date_stamp = date_stamp.replace(i, '.')
results_file = param["full_dir"]+param["dataset_name"]+"results/"+param["Mode"]+"_"+str(image_size)+"_multiclass_test_output"+date_stamp+".txt"
sys.stdout = open(results_file,'w')
print("Mode: "+param["Mode"])
test_file = "testing20multiclass10percent.csv"
train_file = "training80multiclass10percent.csv"
if not param["LoadFromPickle"]:
    data = {}
    if param["class_mode"] == "binary":
        print("Operating in Binary Mode.")
    else:
        print("Operating in Multiclass Mode.")
    with open(param["full_dir"]+param["dataset_name"]+train_file, 'r') as file:
        data["Xtrain"] =pd.read_csv(file)
        data["Xtrain"].replace(np.nan, 0, inplace=True)
        print(data["Xtrain"].head())
        data["Classification"] = np.asarray(data["Xtrain"][param["classif_label"]])
        print("Number of unique attack labels: "+str(len(np.unique(data["Classification"]))))
        param["outputs"] = len(np.unique(data["Classification"]))
        print("Output counts: ")
        print(np.unique(data["Classification"], return_counts=True))
        del data["Xtrain"][param["classif_label"]]
        f = open(param["full_dir"]+"Xtrain.pickle",'wb')
        pickle.dump(data["Xtrain"], f)
        f.close()
        f = open(param["full_dir"]+"Classification.pickle",'wb')
        pickle.dump(data["Classification"],f)
        f.close()

    with open(param["full_dir"] +param["dataset_name"]+ test_file, 'r') as file:
        Xtest = pd.read_csv(file)
        Xtest.replace(np.nan, 0, inplace=True)
        print(Xtest.shape)
        data["Xtest"] = Xtest.astype(float)
        data["Ytest"] = np.asarray(data["Xtest"][param["classif_label"]])
        print("Output counts: ")
        print(np.unique(data["Ytest"], return_counts=True))
        del data["Xtest"][param["classif_label"]]
    len = np.unique(data["Classification"])
    test_output_counts = 0
    train_output_counts = 0
    if param["class_mode"] == "binary" and param["attack_label"] != 1 and param["attack_label"] != 0:
        if param["exclude"] != -1:
            data["Classification"] = data["Classification"][data["Classification"]!=param["exclude"]]
            data["Ytest"] = data["Ytest"][data["Ytest"]!=param["exclude"]]
        np.place(data["Classification"], data["Classification"]==0,1)
        print(np.vstack(np.unique(data["Classification"], return_counts=True)).T)
        np.place(data["Ytest"], data["Ytest"]==0,1)
        np.place(data["Classification"],data["Classification"]==param["attack_label"], 0)
        print(np.vstack(np.unique(data["Classification"], return_counts=True)).T)
        np.place(data["Classification"],data["Classification"]!=0, 1)
        np.place(data["Ytest"],data["Ytest"]==param["attack_label"], 1)
        print(np.vstack(np.unique(data["Classification"], return_counts=True)).T)
        np.place(data["Ytest"],data["Ytest"]!=0, 1)
        data["Xtest"] = Xtest.astype(float)
        data["Ytest"] = data["Xtest"][param["classif_label"]]
        del data["Xtest"][param["classif_label"]]
        print(data["Ytest"].value_counts())
        if (data["Xtest"].shape[0]) < data["Ytest"].shape[0]:
            length = data["Ytest"].shape[0]
            finalIndex = data["Ytest"].shape[0]-(data["Xtest"].shape[0])
            data["Ytest"] = data["Ytest"][:(length-finalIndex)]
            print("Removed extra label.")
        if (data["Xtest"].shape[0]) > data["Ytest"].shape[0]:
            length = data["Xtest"].shape[0]
            finalIndex = data["Xtest"].shape[0]-data["Ytest"].shape[0]
            data["Xtest"] = data["Xtest"][::(length-finalIndex)]
            print("Removed extra sample.")
        if (data["Xtrain"].shape[0]) > data["Classification"].shape[0]:
            length = data["Xtrain"].shape[0]
            finalIndex = data["Xtrain"].shape[0]-(data["Classification"].shape[0])
            data["Xtrain"] = data["Xtrain"][:(length-finalIndex)]
            print("Removed extra label.")
        if (data["Classification"].shape[0]) > data["Xtrain"].shape[0]:
            length = data["Classification"].shape[0]
            finalIndex = data["Classification"].shape[0]-data["Xtrain"].shape[0]
            data["Classification"] = data["Classification"][::(length-finalIndex)]
            print("Removed extra sample.")
        train_output_counts = (np.vstack(np.unique(data["Classification"], return_counts=True)).T)
        test_output_counts = (np.vstack(np.unique(data["Ytest"], return_counts=True)).T)
        print("Train Counts in Binary Mode: "+str(train_output_counts))
        print("Test output counts in Binary Mode: "+str(test_output_counts))
    if param["enhanced_dataset"] == "smote":
        sm = SMOTE(random_state=42)
        data["Xtrain"], data["Classification"] = sm.fit_resample(data["Xtrain"], data["Classification"])
    elif param["enhanced_dataset"] == "adasyn":
        ada = ADASYN(random_state=42)
        data["Xtrain"], data["Classification"] = ada.fit_resample(data["Xtrain"], data["Classification"])

    model = train.train_norm(param, data, norm=False)

else:
    dataset = {}
    if param['mutual_info']:
        method = 'MI'
    else:
        method = 'Mean'

    if param["enhanced_dataset"] == "gan":
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+'XTrain50A.pickle', 'rb')
        dataset["Xtrain"] =pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+'YTrain50A.pickle', 'rb')
        dataset["Classification"] = pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+"TestImages.pickle",'rb')
        dataset["Xtest"] = pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+"TestLabels.pickle",'rb')
        dataset["Ytest"] = pickle.load(f_myfile)
        f_myfile.close()
        train_output_counts = (np.vstack(np.unique(np.argmax(dataset["Classification"],axis=1), return_counts=True)).T)
        test_output_counts = (np.vstack(np.unique(np.argmax(dataset["Ytest"],axis=1), return_counts=True)).T)
        print("Training Output counts: ")
        print(np.asarray(train_output_counts))
        print("Testing Output counts: ")
        print(np.asarray(test_output_counts))

    else:
        f_myfile = open(param["full_dir"] + param['dataset_name'] + param["classif_label"]+'10TrainImages.pickle', 'rb')
        dataset["Xtrain"] =pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["full_dir"] + param['dataset_name'] + param["classif_label"]+'10TrainLabels.pickle', 'rb')
        dataset["Classification"] = pickle.load(f_myfile)
        f_myfile.close()
    
        f_myfile = open(param["full_dir"] + param['dataset_name'] + param["classif_label"]+"10TestImages.pickle",'rb')
        dataset["Xtest"] = pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["full_dir"] + param['dataset_name'] + param["classif_label"]+"10TestLabels.pickle",'rb')
        dataset["Ytest"] = pickle.load(f_myfile)
        f_myfile.close()
        
        print("Image shape: "+str(np.asarray(dataset["Xtrain"]).shape))
        print("Label shape: "+str(np.asarray(dataset["Classification"]).shape))
        print("Test image shape: "+str(np.asarray(dataset["Xtest"]).shape))
        print("Test labels shape "+str(np.asarray(dataset["Ytest"]).shape))
        len = np.unique(dataset["Classification"])
        test_output_counts = 0
        train_output_counts = 0
        if param["class_mode"] == "binary" and param["attack_label"] != 0 and param["attack_label"] != 1:
#           if param["exclude"] != -1: # if there is an extra label or one that is not necessary..
#               dataset["Classification"] = dataset["Classification"][dataset["Classification"]!=param["exclude"]]
#               dataset["Ytest"] = dataset["Ytest"][dataset["Ytest"]!=param["exclude"]]
            np.place(dataset["Classification"], dataset["Classification"]==0,1)
            print(np.vstack(np.unique(dataset["Classification"], return_counts=True)).T)
            np.place(dataset["Ytest"], dataset["Ytest"]==0,1)
            np.place(dataset["Classification"],dataset["Classification"]==param["attack_label"], 0)
            np.place(dataset["Classification"],dataset["Classification"]!=0, 1)
            np.place(dataset["Ytest"],dataset["Ytest"]==param["attack_label"], 0)
            np.place(dataset["Ytest"],dataset["Ytest"]!=0, 1)
            if (dataset["Xtest"].shape[0]) < dataset["Ytest"].shape[0]:
                length = dataset["Ytest"].shape[0]
                finalIndex = dataset["Ytest"].shape[0]-(dataset["Xtest"].shape[0])
                dataset["Ytest"] = dataset["Ytest"][:(length-finalIndex)]
                print("Removed extra label.")
            if (dataset["Xtest"].shape[0]) > dataset["Ytest"].shape[0]:
                length = dataset["Xtest"].shape[0]
                finalIndex = dataset["Xtest"].shape[0]-dataset["Ytest"].shape[0]
                dataset["Xtest"] = dataset["Xtest"][::(length-finalIndex)]
                print("Removed extra sample.")
            if (dataset["Xtrain"].shape[0]) > dataset["Classification"].shape[0]:
                length = dataset["Xtrain"].shape[0]
                finalIndex = dataset["Xtrain"].shape[0]-(dataset["Classification"].shape[0])
                dataset["Xtrain"] = dataset["Xtrain"][:(length-finalIndex)]
                print("Removed extra label.")
            if (dataset["Classification"].shape[0]) > dataset["Xtrain"].shape[0]:
                length = dataset["Classification"].shape[0]
                finalIndex = dataset["Classification"].shape[0]-dataset["Xtrain"].shape[0]
                dataset["Classification"] = dataset["Classification"][::(length-finalIndex)]
                print("Removed extra sample.")
            train_output_counts = (np.vstack(np.unique(dataset["Classification"], return_counts=True)).T)
            test_output_counts = (np.vstack(np.unique(dataset["Ytest"], return_counts=True)).T)
            
        elif param["class_mode"] == "binary" and param["attack_label"] == 1:
            np.place(dataset["Classification"], dataset["Classification"]==1,len)
            print(np.unique(dataset["Classification"], return_counts=True))
            np.place(dataset["Ytest"], dataset["Ytest"]==1,len)
            np.place(dataset["Classification"],dataset["Classification"]==param["attack_label"], 1)
            np.place(dataset["Classification"],dataset["Classification"]!=1, 0)
            np.place(dataset["Ytest"],dataset["Ytest"]==param["attack_label"], 1)
            np.place(dataset["Ytest"],dataset["Ytest"]!=1, 0)
            if (dataset["Xtest"].shape[0]) < dataset["Ytest"].shape[0]:
                length = dataset["Ytest"].shape[0]
                finalIndex = dataset["Ytest"].shape[0]-(dataset["Xtest"].shape[0])
                dataset["Ytest"] = dataset["Ytest"][:(length-finalIndex)]
                print("Removed extra label.")
            if (dataset["Xtest"].shape[0]) > dataset["Ytest"].shape[0]:
                length = dataset["Xtest"].shape[0]
                finalIndex = dataset["Xtest"].shape[0]-dataset["Ytest"].shape[0]
                dataset["Xtest"] = dataset["Xtest"][::(length-finalIndex)]
                print("Removed extra sample.")
            if (dataset["Xtrain"].shape[0]) > dataset["Classification"].shape[0]:
                length = dataset["Xtrain"].shape[0]
                finalIndex = dataset["Xtrain"].shape[0]-(dataset["Classification"].shape[0])
                dataset["Xtrain"] = dataset["Xtrain"][:(length-finalIndex)]
                print("Removed extra label.")
            if (dataset["Classification"].shape[0]) > dataset["Xtrain"].shape[0]:
                length = dataset["Classification"].shape[0]
                finalIndex = dataset["Classification"].shape[0]-dataset["Xtrain"].shape[0]
                dataset["Classification"] = dataset["Classification"][::(length-finalIndex)]
                print("Removed extra sample.")
            train_output_counts = (np.vstack(np.unique(dataset["Classification"], return_counts=True)).T)
            test_output_counts = (np.vstack(np.unique(dataset["Ytest"], return_counts=True)).T)
        else:
            train_output_counts = (np.vstack(np.unique(dataset["Classification"], return_counts=True)).T)
            test_output_counts = (np.vstack(np.unique(dataset["Ytest"], return_counts=True)).T)
            if (dataset["Xtest"].shape[0]) < dataset["Ytest"].shape[0]:
                length = dataset["Ytest"].shape[0]
                finalIndex = dataset["Ytest"].shape[0]-(dataset["Xtest"].shape[0])
                dataset["Ytest"] = dataset["Ytest"][:(length-finalIndex)]
                print("Removed extra label.")
            if (dataset["Xtest"].shape[0]) > dataset["Ytest"].shape[0]:
                length = dataset["Xtest"].shape[0]
                finalIndex = dataset["Xtest"].shape[0]-dataset["Ytest"].shape[0]
                dataset["Xtest"] = dataset["Xtest"][::(length-finalIndex)]
                print("Removed extra sample.")
            if (dataset["Xtrain"].shape[0]) > dataset["Classification"].shape[0]:
                length = dataset["Xtrain"].shape[0]
                finalIndex = dataset["Xtrain"].shape[0]-(dataset["Classification"].shape[0])
                dataset["Xtrain"] = dataset["Xtrain"][:(length-finalIndex)]
                print("Removed extra label.")
            if (dataset["Classification"].shape[0]) > dataset["Xtrain"].shape[0]:
                length = dataset["Classification"].shape[0]
                finalIndex = dataset["Classification"].shape[0]-dataset["Xtrain"].shape[0]
                dataset["Classification"] = dataset["Classification"][::(length-finalIndex)]
                print("Removed extra sample.")
        if param["class_mode"] == "binary":
            print("Operating in Binary Mode.")
        else:
            print("Operating in Multiclass Mode.")
        if (dataset["Xtest"].shape[0]) < dataset["Ytest"].shape[0]:
            length = dataset["Ytest"].shape[0]
            finalIndex = dataset["Ytest"].shape[0]-(dataset["Xtest"].shape[0])
            dataset["Ytest"] = dataset["Ytest"][:(length-finalIndex)]
            print("Removed extra label.")
        if (dataset["Xtest"].shape[0]) > dataset["Ytest"].shape[0]:
            length = dataset["Xtest"].shape[0]
            finalIndex = dataset["Xtest"].shape[0]-dataset["Ytest"].shape[0]
            dataset["Xtest"] = dataset["Xtest"][::(length-finalIndex)]
            print("Removed extra sample.")
        if (dataset["Xtrain"].shape[0]) > dataset["Classification"].shape[0]:
            length = dataset["Xtrain"].shape[0]
            finalIndex = dataset["Xtrain"].shape[0]-(dataset["Classification"].shape[0])
            dataset["Xtrain"] = dataset["Xtrain"][:(length-finalIndex)]
            print("Removed extra label.")
        if (dataset["Classification"].shape[0]) > dataset["Xtrain"].shape[0]:
            length = dataset["Classification"].shape[0]
            finalIndex = dataset["Classification"].shape[0]-dataset["Xtrain"].shape[0]
            dataset["Classification"] = dataset["Classification"][::(length-finalIndex)]
            print("Removed extra sample.")
        attack_totals = np.unique(dataset["Classification"])
        print("Training Output counts: ")
        print(np.asarray(train_output_counts))
        print("Testing Output counts: ")
        print(np.asarray(test_output_counts))


    model = train.train_norm(param, dataset, norm=False)
    print(model)
    end_time = datetime.now()
    execution_time = end_time-start_time
    print("Total time for execution: "+str(execution_time))
