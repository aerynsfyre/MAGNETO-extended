import os
import pickle
import pandas as pd
import csv
import numpy as np
import logging
from imblearn.over_sampling import SMOTE, ADASYN
from lib import train

import sys
from datetime import datetime

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

#Change in maximum image size from 10x10 to 20x20.
#Change epochs: 2 is the original.
# Parameters
param = {"Max_A_Size": 10, "Max_B_Size": 10, "Dynamic_Size": False, 'Metod': 'tSNE', "ValidRatio": 0.1, "seed": 180,
         "dir": "dataset/", "Mode": "CNN2",  # Mode : CNN_Nature, CNN2, SVM, DT, RF,  Inception (images must be 75x75 or greater for this mode)
         "LoadFromPickle": True, "mutual_info": False,  # Mean or MI
         "hyper_opt_evals": 150, "epoch": 2, "No_0_MI": False,  # True -> Removing 0 MI Features
         "autoencoder": False, "cut": None, "enhanced_dataset": "None",  # gan, smote, adasyn, ""None""
        "save_images": False, "load_images": True, "full_dir": "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO/Dataset2Image/dataset/",
        "tuning": "hyperopt" #hyperopt, skopt, optima
         }

dataset = 3  # change dataset
image_size = param["Max_A_Size"]
if dataset == 1: #Multi class labels
    param["classif_label"] = 'Label'
    param["attack_label"] = 0
    param["outputs"] = 8
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 2:
    param["classif_label"] = 'Attack Type'
    param["attack_label"] = 1.0
    param["outputs"] = 9
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 3:
    param["classif_label"] = 'Label'
    param["attack_label"] = 1.0
    param["outputs"] = 15
    param["dataset_name"] = "BOT-IoT/"
date_stamp = str(datetime.now())
forbidden_characters = [':','/',"\\",'?','<','>','|',"...",".."]
for i in forbidden_characters:
    date_stamp = date_stamp.replace(i, '.')
results_file = param["full_dir"]+param["dataset_name"]+"results/"+param["Mode"]+"_"+str(image_size)+"_multiclass_test_output"+date_stamp+".txt"
sys.stdout = open(results_file,'w')
print("Mode: "+param["Mode"])
test_file = "testingdata20multiclass.csv"
train_file = "trainingdata80multiclass.csv"
if not param["LoadFromPickle"]:
    data = {}
    with open(param["full_dir"]+param["dataset_name"]+train_file, 'r') as file:
        #data = {"Xtrain": pd.DataFrame(list(csv.DictReader(file)))}#.astype(float), "class": 2}
        data["Xtrain"] = pd.read_csv(file)
        #data["Xtrain"].drop(columns=['Unnamed: 0','Unnamed: 0.1'])
        data["Xtrain"].replace(np.nan, 0, inplace=True)
#       data["Xtrain"].dropna(inplace=True)
        print(data["Xtrain"].head())
        data["Classification"] = data["Xtrain"][param["classif_label"]]
        print("Number of unique attack labels: "+str(len(np.unique(data["Classification"]))))
        param["outputs"] = len(np.unique(data["Classification"]))
        print("Output counts: ")
        print(np.unique(data["Classification"], return_counts=True))
        del data["Xtrain"][param["classif_label"]]
        f = open(param["full_dir"]+"Xtrain.pickle",'wb')
        pickle.dump(data["Xtrain"], f)
        f.close()
        f = open(param["full_dir"]+"Classification.pickle",'wb')
        pickle.dump(data["Classification"],f)
        f.close()

    with open(param["full_dir"] +param["dataset_name"]+ test_file, 'r') as file:
        Xtest = pd.read_csv(file)#pd.DataFrame(list(csv.DictReader(file)))
        #Xtest.drop(columns=['Unnamed: 0','Unnamed: 0.1'])
        Xtest.replace(np.nan, 0, inplace=True)
#       Xtest.dropna(inplace=True)
        print(Xtest.shape)
        data["Xtest"] = Xtest.astype(float)
        data["Ytest"] = data["Xtest"][param["classif_label"]]
        print("Output counts: ")
        print(np.unique(data["Ytest"], return_counts=True))
        del data["Xtest"][param["classif_label"]]

    if param["enhanced_dataset"] == "smote":
        sm = SMOTE(random_state=42)
        data["Xtrain"], data["Classification"] = sm.fit_resample(data["Xtrain"], data["Classification"])
    elif param["enhanced_dataset"] == "adasyn":
        ada = ADASYN(random_state=42)
        data["Xtrain"], data["Classification"] = ada.fit_resample(data["Xtrain"], data["Classification"])

    model = train.train_norm(param, data, norm=False)

else:
    dataset = {}
    if param['mutual_info']:
        method = 'MI'
    else:
        method = 'Mean'

    if param["enhanced_dataset"] == "gan":
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+'XTrain50A.pickle', 'rb')
        #all_images = pd.DataFrame()
        dataset["Xtrain"] =pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+'YTrain50A.pickle', 'rb')
        dataset["Classification"] = pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+"TestImages.pickle",'rb')
        dataset["Xtest"] = pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+"TestLabels.pickle",'rb')
        dataset["Ytest"] = pickle.load(f_myfile)
        f_myfile.close()
        train_output_counts = (np.vstack(np.unique(dataset["Classification"], return_counts=True)).T)
        test_output_counts = (np.vstack(np.unique(dataset["Ytest"], return_counts=True)).T)
        print("Training Output counts: ")
        print(np.asarray(train_output_counts))
        print("Testing Output counts: ")
        print(np.asarray(test_output_counts))
    else:
        f_myfile = open(param["full_dir"] + param['dataset_name'] + 'Label10TrainImages.pickle', 'rb')
        #all_images = pd.DataFrame()
        dataset["Xtrain"] =pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["full_dir"] + param['dataset_name'] + 'Label10TrainLabels.pickle', 'rb')
        dataset["Classification"] = pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["full_dir"] + param['dataset_name'] + "Label10TestImages.pickle",'rb')
        dataset["Xtest"] = pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["full_dir"] + param['dataset_name'] + "Label10TestLabels.pickle",'rb')
        dataset["Ytest"] = pickle.load(f_myfile)
        f_myfile.close()
        
        print("Image shape: "+str(np.asarray(dataset["Xtrain"]).shape))
        print("Label shape: "+str(np.asarray(dataset["Classification"]).shape))
        print("Test image shape: "+str(np.asarray(dataset["Xtest"]).shape))
        print("Test labels shape "+str(np.asarray(dataset["Ytest"]).shape))
        if len(dataset["Classification"].shape) >= 2:
            train_output_counts = (np.vstack(np.unique(np.argmax(dataset["Classification"],axis=1), return_counts=True)).T)
        else:
            train_output_counts = (np.vstack(np.unique(dataset["Classification"], return_counts=True)).T)
        if len(dataset["Ytest"].shape) >= 2:
            test_output_counts = (np.vstack(np.unique(np.argmax(dataset["Ytest"], axis=1), return_counts=True)).T)
        else:
            test_output_counts = (np.vstack(np.unique(dataset["Ytest"], return_counts=True)).T)
        print("Training Output counts: ")
        print(np.asarray(train_output_counts))
        print("Testing Output counts: ")
        print(np.asarray(test_output_counts))
        dataset["Classification"] = np.asarray(pd.get_dummies(dataset["Classification"]))
        dataset["Ytest"] = np.asarray(pd.get_dummies(dataset["Ytest"]))

    model = train.train_norm(param, dataset, norm=False)
    print(model)

# PLOT DATA -- PCA/TSNE
# from sklearn.decomposition import PCA
# from sklearn.manifold import TSNE
# from sklearn.preprocessing import MinMaxScaler
# import matplotlib.pyplot as plt
# pca = TSNE(n_components=2)
# principalComponents = pca.fit_transform(data["Xtrain"])
#
#
# scaler = MinMaxScaler(feature_range=(0, 10))
# scaled_data = scaler.fit_transform(principalComponents)
#
# attacks = np.where(data["Classification"] == 0)
# attacks = scaled_data[attacks[0]]
#
# normals = np.where(data["Classification"] == 1)
# normals = scaled_data[normals[0]]
#
# plt.scatter(attacks[:, 0], attacks[:, 1], color="red", s=1)
#
# plt.scatter(normals[:, 0], normals[:, 1], color="blue", s=1)
#
# plt.show()
# df = pd.DataFrame(scaled_data)
# df["label"] = data["Classification"]
# df.to_csv("AAGM-TSNE_minmax.csv", index=False)
    