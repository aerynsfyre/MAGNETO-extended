import csv
import json
import pickle
import timeit

import numpy as np
from hyperopt import STATUS_OK
from hyperopt import tpe, hp, Trials, fmin
from keras import backend as K
from keras.utils import to_categorical
from sklearn.metrics import confusion_matrix, balanced_accuracy_score, f1_score
from sklearn.model_selection import cross_val_score, RepeatedStratifiedKFold
#from skopt import BayesSearchCV

from lib.Cart2Pixel import Cart2Pixel
from lib.ConvPixel import ConvPixel
from lib.deep import CNN_Nature, CNN2, SVM, DecisionTree, InceptionModel, RandomForest
import SaveFunction
import matplotlib.pyplot as plt
import pycm

import time

XGlobal = []
YGlobal = []

XTestGlobal = []
YTestGlobal = []

SavedParameters = []
Mode = ""
Name = ""
best_val_acc = 0

attack_label = 0

global Directory
Directory = ""

def fix(f):
    a = f["TN_val"]
    b = f["FP_val"]
    c = f["FN_val"]
    d = f["TP_val"]
    f["TN_val"] = d
    f["TP_val"] = a
    f["FP_val"] = c
    f["FN_val"] = b
    return f


def fix_test(f):
    a = f["TN_test"]
    b = f["FP_test"]
    c = f["FN_test"]
    d = f["TP_test"]
    f["TN_test"] = d
    f["TP_test"] = a
    f["FP_test"] = c
    f["FN_test"] = b
    return f


def res(cm, val,cf,param):
#   tp = cm[0][0]  # attacks true
#   fn = cm[0][1]  # attacs predict normal
#   fp = cm[1][0]  # normal predict attacks
#   tn = cm[1][1]  # normal as normal
    degree = 6
    #get TP
    t = 0
    tp_vals = cf.TP
    for i in tp_vals:
        t = t + tp_vals[i]
    tp = t
    t = 0
    #get FN
    fn_vals = cf.FN
    for i in fn_vals:
        t = t + fn_vals[i]
    fn = t
    t = 0
    #get FP
    fp_vals = cf.FP
    for i in fp_vals:
        t = t + fp_vals[i]
    fp = t
    t = 0
    #get TN
    tn_vals = cf.TN
    for i in tn_vals:
        t = t + tn_vals[i]
    tn = t
    
#   tp = cf.TPR_Micro
#   fn = cf.FNR_Micro
#   fp = cf.FPR_Micro
#   tn = cf.TNR_Micro
    
    attacks = tp + fn
    normals = fp + tn
    print(attacks)
    print(normals)

    if attacks <= normals:
        print("ok")
    elif not val:
        print("error")
        return False, False
    OA = cf.Overall_ACC #(tp + tn) / (attacks + normals)
    AA = cf.Overall_ACC #((tp / attacks) + (tn / normals)) / 2
    P = tp / (tp + fp)
    R = tp / (tp + fn)
    F1 = cf.F1_Macro #2 * ((P * R) / (P + R))
    FAR = fp / (fp + tn)
    TPR = cf.TPR_Macro # tp / (tp + fn)
    r = [OA, AA, P, R, F1, FAR, TPR]
    return True, r, [tp,fp,fn,tn]


# hyperopt function to optimize
def hyperopt_fcn(params):
    if Mode == "CNN_Nature" and params["filter"] == params["filter2"]:
        return {'loss': np.inf, 'status': STATUS_OK}
    global SavedParameters
    start_time = time.time()
    print("start train")
    if Mode == "CNN_Nature":
        model, val = CNN_Nature(XGlobal, YGlobal, XTestGlobal, YTestGlobal, Directory, params)
        
    elif Mode == "CNN2":
        model, val = CNN2(XGlobal, YGlobal, XTestGlobal, YTestGlobal, Directory, params)
        
    elif Mode == "SVM":
        model,val = SVM(XGlobal, YGlobal, XTestGlobal, YTestGlobal, Directory, params)
    
    elif Mode == "DT":
        model,val = DecisionTree(XGlobal, YGlobal, XTestGlobal, YTestGlobal, Directory, params)
    
    elif Mode == "RF":
        model,val = RandomForest(XGlobal, YGlobal, XTestGlobal, YTestGlobal, Directory, params)
    else:
        model,val = InceptionModel(XGlobal, YGlobal, XTestGlobal, YTestGlobal, Directory, params)
    print("start predict")
    if Mode == "CNN2" or Mode == "CNN_Nature":
        y_predicted = model.predict(XTestGlobal, verbose=0, use_multiprocessing=True, workers=20)
    else:
        y_predicted = model.predict(np.reshape(XTestGlobal, [-1, (XTestGlobal.shape[1]*XTestGlobal.shape[2])]))
    if Mode == "CNN2" or Mode == "CNN_Nature":
        y_predicted = np.argmax(y_predicted, axis=1)
    elapsed_time = time.time() - start_time
    if len(YTestGlobal.shape) >= 2:
        cf = pycm.ConfusionMatrix(np.argmax(YTestGlobal,axis=1), y_predicted)
    else:
        cf = pycm.ConfusionMatrix(YTestGlobal, y_predicted)
    print(cf)
    # print("test F1_score: " + str(f1_score(YTestGlobal, y_predicted)))
    K.clear_session()
    SavedParameters.append(val)
    global best_val_acc
    print("val acc: " + str(cf.Overall_ACC*100))

    if Mode == "CNN_Nature":
        SavedParameters[-1].update({"balanced_accuracy_test": cf.Overall_ACC *
                                                              100, "TP_test": cf.TPR_Micro, "FN_test": cf.FNR_Micro,
                                    "FP_test": cf.FPR_Micro, "TN_test": cf.TNR_Micro, "kernel": params[
                "kernel"], "learning_rate": params["learning_rate"], "batch": params["batch"],
                                    "filter1": params["filter"],
                                    "filter2": params["filter2"],
                                    "time": time.strftime("%H:%M:%S", time.gmtime(elapsed_time))})
    elif Mode == "CNN2":
        SavedParameters[-1].update(
            {"balanced_accuracy_test": cf.Overall_ACC *
                100, "TP_test": cf.TPR_Micro, "FN_test": cf.FNR_Micro,
                "FP_test": cf.FPR_Micro, "TN_test": cf.TNR_Micro, "kernel": params["kernel"],
         "learning_rate": params["learning_rate"],
         "batch": params["batch"],
         "dropout1": params["dropout1"],
         "dropout2": params["dropout2"],
         "time": time.strftime("%H:%M:%S", time.gmtime(elapsed_time))})
    elif Mode == "SVM":
        SavedParameters[-1].update(
            {"balanced_accuracy_test": cf.Overall_ACC *100, "TP_test": cf.TPR_Micro, "FN_test": cf.FNR_Micro, "FP_test": cf.FPR_Micro, "TN_test": cf.TNR_Micro,
            "gamma": params["gamma"],
            "C": params["C"],
            "learning_rate": params["learning_rate"],
            "batch": params["batch"],
            "time": time.strftime("%H:%M:%S", time.gmtime(elapsed_time))}
        )
    elif Mode == "DT":
        SavedParameters[-1].update(
            {"balanced_accuracy_test": cf.Overall_ACC *100, "TP_test": cf.TPR_Micro, "FN_test": cf.FNR_Micro, "FP_test": cf.FPR_Micro, "TN_test": cf.TNR_Micro,
            "max_depth": params["max_depth"],
            "random_state": params["random_state"],
            "learning_rate": params["learning_rate"],
            "batch": params["batch"],
            "time": time.strftime("%H:%M:%S", time.gmtime(elapsed_time))}
        )
    elif Mode == "RF":
        SavedParameters[-1].update(
            {"balanced_accuracy_test": cf.Overall_ACC *100, "TP_test": cf.TPR_Micro, "FN_test": cf.FNR_Micro, "FP_test": cf.FPR_Micro, "TN_test": cf.TNR_Micro,
            "max_depth": params["max_depth"],
            "random_state": params["random_state"],
            "time": time.strftime("%H:%M:%S", time.gmtime(elapsed_time))}
        )
        
    elif Mode == "Inception":
        SavedParameters[-1].update(
            {"balanced_accuracy_test": cf.Overall_ACC *
                100, "TP_test": cf.TPR_Micro, "FN_test": cf.FNR_Micro,
                "FP_test": cf.FPR_Micro, "TN_test": cf.TNR_Micro, "kernel": params["kernel"],
         "learning_rate": params["learning_rate"],
         "batch": params["batch"],
         "time": time.strftime("%H:%M:%S", time.gmtime(elapsed_time))})
    cm_val = [[SavedParameters[-1]["TP_val"], SavedParameters[-1]["FN_val"]],
              [SavedParameters[-1]["FP_val"], SavedParameters[-1]["TN_val"]]]
    
    value, r, vals = res(cm_val, True, cf, params)
    
    if value is True:
        SavedParameters[-1].update({
            "OA_val": r[0],
            "P_val": r[2],
            "R_val": r[3],
            "F1_val": r[4],
            "FAR_val": r[5],
            "TPR_val": r[6]
        })
    cm_test = [[SavedParameters[-1]["TP_test"], SavedParameters[-1]["FN_test"]],
               [SavedParameters[-1]["FP_test"], SavedParameters[-1]["TN_test"]]]
    value, r, vals = res(cm_test, False, cf, params)
    if value is True:
        SavedParameters[-1].update({
            "OA_test": r[0],
            "P_test": r[2],
            "R_test": r[3],
            "F1_test": r[4],
            "FAR_test": r[5],
            "TPR_test": r[6]
        })

    # Save model
    if SavedParameters[-1]["OA_val"] > best_val_acc:
        print("new saved model:" + str(SavedParameters[-1]))
        if Mode == "SVM" or Mode == "DT" or Mode == "RF":
            f = open(Directory+"best_model.pickle",'wb')
            pickle.dump(model,f)
            f.close()
        else: 
            model.save(Directory+(Name.replace(".csv", "_model.h5")))
        best_val_acc = SavedParameters[-1]["OA_val"]
        print("Accuracy of model: "+ str(SavedParameters[-1]))

    SavedParameters = sorted(SavedParameters, key=lambda i: i['F1_val'], reverse=True)

    try:
        with open(Directory+Name, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=SavedParameters[0].keys())
            writer.writeheader()
            writer.writerows(SavedParameters)
    except IOError:
        print("I/O error")
    return {'loss': -val["F1_val"], 'status': STATUS_OK}

def bayes_search_cv(params):
    cv = RepeatedStratifiedKFold(n_splits=10, n_repeats=3, random_state=1)
    if Mode == "CNN_Nature":
        model, val = CNN_Nature(XGlobal, YGlobal, XTestGlobal, YTestGlobal, Directory, params)
        
    elif Mode == "CNN2":
        model, val = CNN2(XGlobal, YGlobal, XTestGlobal, YTestGlobal, Directory, params)
    params["C"] = (1e-6, 100.0, 'log-uniform')
    params["gamma"] = (1e-6, 100.0, 'log-uniform')
    params['degree'] = (1,5)
    params['kernel'] = ['linear','poly','rbf','softmax']
    ##search = BayesSearchCV(estimator=model,search_space=params, n_jobs=-1,cv=cv)
    #search.fit(XGlobal,YGlobal)
    #print(search.best_score_)
    #print(search.best_params_)
    
def train_norm(param, dataset, norm):
    np.random.seed(param["seed"])
    print("modelling dataset")
    global YGlobal
    global YTestGlobal
    num_outputs = len(np.unique(dataset["Classification"]))
    # Make sure the output labels are categorical.
    if (len(dataset["Classification"])) <2:
        YGlobal = to_categorical(dataset["Classification"]) #to_categorical()
    else:
        YGlobal = (dataset["Classification"])
    if (len(dataset["Ytest"])) < 2:
        YTestGlobal = to_categorical(dataset["Ytest"])
    else:
        YTestGlobal = (dataset["Ytest"])
    del dataset["Classification"], dataset["Ytest"]
     #)
    
    #del dataset["Ytest"]

    global XGlobal
    global XTestGlobal 

    if not param["LoadFromPickle"]:
        # norm
        Out = {}
        if norm:
            print('NORM Min-Max')
            Out["Max"] = float(dataset["Xtrain"].max().max())
            Out["Min"] = float(dataset["Xtrain"].min().min())
            # NORM
            dataset["Xtrain"] = (dataset["Xtrain"] - Out["Min"]) / (Out["Max"] - Out["Min"])
            dataset["Xtrain"] = dataset["Xtrain"].fillna(0)

        print("trasposing")

        q = {"data": np.array(dataset["Xtrain"].values).transpose(), "method": param["Metod"],
             "max_A_size": param["Max_A_Size"], "max_B_size": param["Max_B_Size"], "y": YGlobal}
        print(q["method"])
        print(q["max_A_size"])
        print(q["max_B_size"])
                # generate images
        if param["save_images"] is True:
            XGlobal, image_model, toDelete = Cart2Pixel(q, q["max_A_size"], q["max_B_size"], param["Dynamic_Size"],
                                                        mutual_info=param["mutual_info"], params=param, only_model=False)
            
            #create(param['dataset_name']+'/TrainImages.pickle')
            train_file = open((param["full_dir"]+param['dataset_name']+'MulticlassTrainImages.pickle'),'wb')
            pickle.dump(XGlobal,train_file)
            train_file.close()
            test_file = open((param["full_dir"]+param['dataset_name']+'MulticlassTrainLabels.pickle'),'wb')
            pickle.dump(YGlobal,test_file)
            test_file.close()
            del q["data"]
            print("Train Images done!")
            # generate testing set image
            if param["mutual_info"]:
                dataset["Xtest"] = dataset["Xtest"].drop(dataset["Xtest"].columns[toDelete], axis=1)
    
            x = image_model["xp"]
            y = image_model["yp"]
            col = dataset["Xtest"].columns
            # col = col.delete(0)
            # print(col)
            # coordinate model
            coor_model = {"coord": ["xp: " + str(i) + "," "yp :" + str(z) + ":" + col for i, z, col in zip(x, y, col)]}
            j = json.dumps(coor_model)
            f = open(param["dir"] + "MI_model.json", "w")
            f.write(j)
            f.close()
    
            dataset["Xtest"] = np.array(dataset["Xtest"]).transpose()
            print("generating Test Images")
            print(dataset["Xtest"].shape)
    
            if image_model["custom_cut"] is not None:
                XTestGlobal = [ConvPixel(dataset["Xtest"][:, i], np.array(image_model["xp"]), np.array(image_model["yp"]),
                                        image_model["A"], image_model["B"], custom_cut=range(0, image_model["custom_cut"]))
                                for i in range(0, dataset["Xtest"].shape[1])]  # dataset["Xtest"].shape[1])]
            else:
                XTestGlobal = [ConvPixel(dataset["Xtest"][:, i], np.array(image_model["xp"]), np.array(image_model["yp"]),
                                        image_model["A"], image_model["B"])
                                for i in range(0, dataset["Xtest"].shape[1])]  # dataset["Xtest"].shape[1])]
                #create(param['dataset_name']+'/TestImages.pickle')
            test_file = open(param["full_dir"]+param['dataset_name']+'MulticlassTestImages.pickle','wb')
            pickle.dump(XTestGlobal,test_file)
            test_file.close()
            test_file = open((param["full_dir"]+param['dataset_name']+'MulticlassTestLabels.pickle'),'wb')
            pickle.dump(YTestGlobal,test_file)
            test_file.close()
            print("Test Images done!")
        if param["load_images"] is True:
            train_file = open(param["full_dir"]+param['dataset_name']+"MulticlassTrainImages.pickle",'rb')
            XGlobal = pickle.load(train_file)
            train_file.close()
            test_file = open(param["full_dir"]+param["dataset_name"]+"MulticlassTestImages.pickle",'rb')
            XTestGlobal = pickle.load(test_file)
            test_file.close()
            model_file = open(param["dir"]+"model_10x10_Mean.json",'rb')
            image_model = json.load(model_file)
            model_file.close()
        # saving testing set
        name = "_" + str(int(q["max_A_size"])) + "x" + str(int(q["max_B_size"]))
        if param["No_0_MI"]:
            name = name + "_No_0_MI"
        if param["mutual_info"]:
            name = name + "_MI"
        else:
            name = name + "_Mean"
        if image_model["custom_cut"] is not None:
            name = name + "_Cut" + str(image_model["custom_cut"])
        filename = param["dir"] + "test" + name + ".pickle"
        f_file = open(filename, 'wb')
        pickle.dump(XTestGlobal, f_file)
        f_file.close()
    else:
        XGlobal = dataset["Xtrain"]
        XTestGlobal = dataset["Xtest"]
    # GAN
    del dataset["Xtrain"]
    del dataset["Xtest"]
    XTestGlobal = np.array(XTestGlobal)
    image_size1, image_size2 = [param["Max_A_Size"],param["Max_B_Size"]]
    XTestGlobal = np.reshape(XTestGlobal, [-1, image_size1, image_size2, 1])
    #YTestGlobal = np.argmax(YTestGlobal, axis=1)
    
    print("Test data shape: "+str(XTestGlobal.shape))
    print("Categorical test labels shape: "+str(YTestGlobal.shape))
    print("Categorical test labels head: ")
    print((YTestGlobal[:10]))
    hyperparameters_to_optimize = {"filter_size": 3, "kernel": 2, "filter_size2": 6,"learning_rate":1e-5}
    # "momentum":0.8}

    if param["Mode"] == "CNN_Nature":
        hyperparameters_to_optimize = {"kernel": hp.choice("kernel", np.arange(2, 4 + 1)),
                                       "filter": hp.choice("filter", [16, 32, 64, 128]),
                                       "filter2": hp.choice("filter2", [16, 32, 64, 128]),
                                       "batch": hp.choice("batch", [32, 64, 128, 256, 512]),
                                       "learning_rate": hp.uniform("learning_rate", 0.0001, 0.01),
                                       "epoch": param["epoch"]}
    elif param["Mode"] == "CNN2":
        hyperparameters_to_optimize = {"kernel": hp.choice("kernel", np.arange(2, 4 + 1)),
                                       "batch": hp.choice("batch", [32, 64, 128, 256, 512]),
                                       'dropout1': hp.uniform("dropout1", 0, 1),
                                       'dropout2': hp.uniform("dropout2", 0, 1),
                                       "learning_rate": hp.uniform("learning_rate", 0.0001, 0.001),
                                       "epoch": param["epoch"]}
    elif param["Mode"] == "SVM":
        hyperparameters_to_optimize = {"kernel": hp.choice("kernel", ["rbf","sigmoid"]),
                                        "degree": hp.choice("degree", [3,4,5,6]),
                                        "gamma": hp.choice("gamma", ["scale", "auto", 1, 0.1, 0.01, 0.001, 0.0001]),
                                        "C": hp.choice("C",[0.1, 1, 10, 100, 1000]),
                                       "batch": hp.choice("batch", [32, 64, 128, 256, 512]),
                                       "learning_rate": hp.uniform("learning_rate", 0.0001, 0.001),
                                       "epoch": param["epoch"]}
    elif param["Mode"] == "DT":
        hyperparameters_to_optimize = {"max_depth": hp.choice("max_depth",[2,3,4]),
                                       "random_state": hp.choice("random_state",[32,42]),
                                       "kernel": hp.choice("kernel", np.arange(2, 4 + 1)),
                                       "batch": hp.choice("batch", [32, 64, 128, 256, 512]),
                                       "learning_rate": hp.uniform("learning_rate", 0.0001, 0.001),
                                       "epoch": param["epoch"]}
    elif param["Mode"] == "Inception":
        hyperparameters_to_optimize = {"kernel": hp.choice("kernel", np.arange(2, 4 + 1)),
                                       "batch": hp.choice("batch", [32, 64, 128, 256, 512]),
                                       "learning_rate": hp.uniform("learning_rate", 0.0001, 0.001),
                                       "epoch": param["epoch"]}
    elif param["Mode"] == "RF":
        hyperparameters_to_optimize = {"random_state": hp.choice("random_state",[32,42]),
                                        "criterion": hp.choice("criterion", ["gini", "entropy", "log_loss"]),
                                        "estimators": hp.choice("estimators",[20,40,60,80,100,120,140,160,180,200]),
                                        "max_depth": hp.choice("max_depth",[2,3,4,5,6,7,8,9,10])
        }
            
    # output name
    global attack_label
    attack_label = param["attack_label"]

    global Mode
    Mode = param["Mode"]
    Directory = param["full_dir"]+param["dataset_name"]

    global Name
    Name = param["dir"] + "res_" + str(int(param["Max_A_Size"])) + "x" + str(int(param["Max_B_Size"]))
    if param["No_0_MI"]:
        Name = Name + "_No_0_MI"
    if param["mutual_info"]:
        Name = Name + "_MI"
    else:
        Name = Name + "_Mean"
    Name = Name + "_" + Mode + ".csv"
    trials = Trials()
    if param["tuning"] == "hyperopt":
        result = fmin(hyperopt_fcn, hyperparameters_to_optimize, trials=trials, algo=tpe.suggest, max_evals=param["hyper_opt_evals"])
    elif param["tuning"] == "skopt":
        bayes_search_cv(param)
    print("done")
    return 1
                                            