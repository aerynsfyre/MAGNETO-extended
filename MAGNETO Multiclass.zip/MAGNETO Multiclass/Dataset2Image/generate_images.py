# Code from Dunmore et al., 2023, "MAGNETO and DeepInsight: Extended Image Translation with Semantic Relationships for Classifying Attack Data with Convolutional Neural Networks".
# Additional code from: 
# Andresini et al., 2021, "GAN augmentation to deal with imbalance in imaging-based intrusion detection" doi: 10.1016/j.future.2021.04.017
# Sharma et al., 2019, "DeepInsight: A methodology to transform a non-image data to an image for convolution neural network architecture" doi: 10.1038/s41598-019-47765-6.
# Please cite these papers if you are going to use any part of this code in further research.

import csv
import json
import pickle
import timeit
import logging

import numpy as np
from hyperopt import STATUS_OK
from hyperopt import tpe, hp, Trials, fmin
from keras import backend as K
from keras.utils import to_categorical
from sklearn.metrics import confusion_matrix, balanced_accuracy_score, f1_score
import pandas as pd

from lib.Cart2Pixel import Cart2Pixel
from lib.ConvPixel import ConvPixel
from lib.deep import CNN_Nature, CNN2
import matplotlib.pyplot as plt
import pycm
from datetime import datetime
import time

XGlobal = []
YGlobal = []

XTestGlobal = []
YTestGlobal = []

SavedParameters = []
Mode = ""
Name = ""
best_val_acc = 0

attack_label = 0

param = {"Max_A_Size": 10, "Max_B_Size": 10, "Dynamic_Size": False, 'Metod': 'tSNE', "ValidRatio": 0.1, "seed": 180,
    "dir": "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO Binary/Dataset2Image/", "Mode": "CNN2",  # Mode : CNN_Nature, CNN2
    "LoadFromPickle": False, "mutual_info": False,  # Mean or MI
    "hyper_opt_evals": 100, "epoch": 2, "No_0_MI": False,  # True -> Removing 0 MI Features
    "autoencoder": False, "cut": None, "enhanced_dataset": "gan",  # gan, smote, adasyn, ""None""
    "dataset_name": "", "save_images": True, "load_images": False, "save_for_gan":True, "full_dir": "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO datasets/",
    "frac_in_use": 1
}

train_file = 'training80multiclass10percent.csv'
test_file = 'testing20multiclass10percent.csv'
param["classif_label"] = 'Label'
param["attack_label"] = 13
param["dataset_name"] = "CICIDS17"

def generate_images(param,dataset):
    np.random.seed(param["seed"])
    print("modelling dataset")
    global YGlobal
    YGlobal = to_categorical(dataset["Classification"])
    del dataset["Classification"]
    global YTestGlobal
    YTestGlobal = to_categorical(dataset["Ytest"])
    del dataset["Ytest"]
    
    global XGlobal
    global XTestGlobal
    
    if not param["LoadFromPickle"]:
        Out = {}
        print("transposing")
        
        q = {"data": np.array(dataset["Xtrain"].values).transpose(), "method": param["Metod"],
             "max_A_size": param["Max_A_Size"], "max_B_size": param["Max_B_Size"], "y": np.argmax(YGlobal, axis=1)}
        print(q["method"])
        print(q["max_A_size"])
        print(q["max_B_size"])
        
        # generate images
        if param["save_images"] is True and param['LoadFromPickle'] is False:
            XGlobal, image_model, toDelete = Cart2Pixel(q, q["max_A_size"], q["max_B_size"], param["Dynamic_Size"],
                                                        mutual_info=param["mutual_info"], params=param, only_model=False)
            train_file = open((param["full_dir"]+param['dataset_name']+'/TrainImages.pickle'),'wb')
            pickle.dump(XGlobal,train_file)
            train_file.close()
            del q["data"]
            print("Train Images done!")
            # generate testing set image
            if param["mutual_info"]:
                dataset["Xtest"] = dataset["Xtest"].drop(dataset["Xtest"].columns[toDelete], axis=1)
                
            x = image_model["xp"]
            y = image_model["yp"]
            col = dataset["Xtest"].columns

            # coordinate model
            coor_model = {"coord": ["xp: " + str(i) + "," "yp :" + str(z) + ":" + col for i, z, col in zip(x, y, col)]}
            j = json.dumps(coor_model)
            f = open(param["full_dir"] + "MI_model.json", "w")
            f.write(j)
            f.close()
            
            dataset["Xtest"] = np.array(dataset["Xtest"]).transpose()
            print("generating Test Images")
            print(dataset["Xtest"].shape)
            
            if image_model["custom_cut"] is not None:
                XTestGlobal = [ConvPixel(dataset["Xtest"][:, i], np.array(image_model["xp"]), np.array(image_model["yp"]),
                                        image_model["A"], image_model["B"], custom_cut=range(0, image_model["custom_cut"]))
                                for i in range(0, (dataset["Xtest"].shape[1]-1))] 
            else:
                XTestGlobal = [ConvPixel(dataset["Xtest"][:, i], np.array(image_model["xp"]), np.array(image_model["yp"]),
                                        image_model["A"], image_model["B"])
                                for i in range(0, (dataset["Xtest"].shape[1]-1))]
            test_file = open((param["full_dir"]+param['dataset_name']+'/TestImages.pickle'),'wb')
            pickle.dump(XTestGlobal,test_file)
            test_file.close()
            print("Test Images done!")
        if param["load_images"] is True and param['LoadFromPickle'] is False:
            train = open((param['full_dir']+param['dataset_name']+"TrainImages.pickle"),'rb')
            XGlobal = pickle.load(train)
            train.close()
            test = open((param["full_dir"]+param['dataset_name']+"TestImages.pickle"),'rb')
            XTestGlobal = pickle.load(test)
            test.close()
            
    else:
        XGlobal = dataset["Xtrain"]
        XTestGlobal = dataset["Xtest"]
    # GAN
    del dataset["Xtrain"]
    del dataset["Xtest"]
    XTestGlobal = np.array(XTestGlobal)
    image_size1 = param["Max_A_Size"]
    image_size2 = param["Max_B_Size"]
    XTestGlobal = np.reshape(XTestGlobal, [-1, image_size1, image_size2, 1])
    XGlobal = np.reshape(XGlobal, [-1, image_size1, image_size2, 1])
    YTestGlobal = np.argmax(YTestGlobal, axis=1)
    YGlobal = np.argmax(YGlobal, axis=1)
    print("XTrain shape: "+str(XGlobal.shape))
    print("YTrain shape: "+str(YGlobal.shape))
    if param["save_for_gan"] is True: 
        f = open(param["full_dir"]+param["dataset_name"]+"/"+param["classif_label"]+str(param["Max_A_Size"])+"TestImages.pickle",'wb')
        pickle.dump(XTestGlobal,f)
        f.close()
        f = open(param["full_dir"]+param["dataset_name"]+"/"+param["classif_label"]+str(param["Max_A_Size"])+"TestLabels.pickle",'wb')
        pickle.dump(YTestGlobal,f)
        f.close()
        f = open(param["full_dir"]+param["dataset_name"]+"/"+param["classif_label"]+str(param["Max_A_Size"])+"TrainImages.pickle",'wb')
        pickle.dump(XGlobal,f)
        f.close()
        f = open(param["full_dir"]+param["dataset_name"]+"/"+param["classif_label"]+str(param["Max_A_Size"])+"TrainLabels.pickle",'wb')
        pickle.dump(YGlobal,f)
        f.close()

start_time = datetime.now()
data = {}
with open(param["full_dir"]+param["dataset_name"]+"/"+train_file, 'r') as file:
    data["Xtrain"] = pd.read_csv(file).sample(frac=param["frac_in_use"])
    print("Fraction of dataset in use: "+str(param["frac_in_use"]*100)+"%")
    print("Attack label: "+str(param["classif_label"]))
    data["Xtrain"].replace(np.nan, 0, inplace=True)
    print(data["Xtrain"].head())
    print("Number of counts for attack labels: ")
    data["Classification"] = data["Xtrain"][param["classif_label"]]
    del data["Xtrain"][param["classif_label"]]
    f = open(param["full_dir"]+param["dataset_name"]+"Xtrain.pickle",'wb')
    pickle.dump(data["Xtrain"], f)
    f.close()
    f = open(param["full_dir"]+param["dataset_name"]+"Classification.pickle",'wb')
    pickle.dump(data["Classification"],f)
    f.close()
    print(data["Classification"].value_counts())
    
with open(param["full_dir"]+param["dataset_name"]+"/"+test_file, 'r') as file:
    Xtest = pd.read_csv(file).sample(frac=param["frac_in_use"]) 
    Xtest.replace(np.nan, 0, inplace=True)
    print(Xtest.shape)
    data["Xtest"] = Xtest.astype(float)
    data["Ytest"] = data["Xtest"][param["classif_label"]]
    del data["Xtest"][param["classif_label"]]
    print(data["Ytest"].value_counts())
if (data["Xtest"].shape[0]) < data["Ytest"].shape[0]:
    length = data["Ytest"].shape[0]
    finalIndex = data["Ytest"].shape[0]-(data["Xtest"].shape[0])
    data["Ytest"] = data["Ytest"][:(length-finalIndex)]
    print("Removed extra label.")
if (data["Xtest"].shape[0]) > data["Ytest"].shape[0]:
    length = data["Xtest"].shape[0]
    finalIndex = data["Xtest"].shape[0]-data["Ytest"].shape[0]
    data["Xtest"] = data["Xtest"][::(length-finalIndex)]
    print("Removed extra sample.")
if (data["Xtrain"].shape[0]) > data["Classification"].shape[0]:
    length = data["Xtrain"].shape[0]
    finalIndex = data["Xtrain"].shape[0]-(data["Classification"].shape[0])
    data["Xtrain"] = data["Xtrain"][:(length-finalIndex)]
    print("Removed extra label.")
if (data["Classification"].shape[0]) > data["Xtrain"].shape[0]:
    length = data["Classification"].shape[0]
    finalIndex = data["Classification"].shape[0]-data["Xtrain"].shape[0]
    data["Classification"] = data["Classification"][::(length-finalIndex)]
    print("Removed extra sample.")
print("Training Image shape: "+str(data["Xtrain"].shape))
print("Training Label shape: "+str(data["Classification"].shape))
print("Testing Image shape: "+str(data["Xtest"].shape))
print("Testing Label shape: "+str(data["Ytest"].shape))
generate_images(param,data)
end_time = datetime.now()
total_time = end_time-start_time
print("Time taken: "+str(total_time))