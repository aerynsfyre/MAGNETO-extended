.. _keras_ref:

Batch generator for Keras
=========================

.. automodule:: imblearn.keras
    :no-members:
    :no-inherited-members:

.. currentmodule:: imblearn

.. autosummary::
   :toctree: generated/
   :template: class.rst

   keras.BalancedBatchGenerator

.. autosummary::
   :toctree: generated/
   :template: function.rst

   keras.balanced_batch_generator
