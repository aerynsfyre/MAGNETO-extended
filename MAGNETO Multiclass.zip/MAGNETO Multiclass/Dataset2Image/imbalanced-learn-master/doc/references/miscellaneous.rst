.. _misc_ref:

Miscellaneous
=============

Imbalance-learn provides some fast-prototyping tools.

.. currentmodule:: imblearn

.. autosummary::
   :toctree: generated/
   :template: class.rst

   FunctionSampler
