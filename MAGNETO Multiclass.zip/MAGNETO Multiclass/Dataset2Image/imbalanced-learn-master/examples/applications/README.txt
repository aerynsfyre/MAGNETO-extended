.. _realword_examples:

Examples based on real world datasets
-------------------------------------

Examples which use real-word dataset.
