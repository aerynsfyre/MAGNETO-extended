import os
import pickle
import pandas as pd
import csv
import numpy as np
import logging
from imblearn.over_sampling import SMOTE, ADASYN
from lib import train
import sys
from datetime import datetime
#from knockknock import email_sender

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
#Change in maximum image size from 10x10 to 20x20.
#Change epochs: 2 is the original.
# Parameters
# Chage dataset_name and dir depending on the dataset in use.
param = {"Max_A_Size": 10, "Max_B_Size": 10, "Dynamic_Size": False, 'Metod': 'tSNE', "ValidRatio": 0.1, "seed": 180,
         "dir": "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO/Dataset2Image/dataset/", "Mode": "CNN2",  # Mode : CNN_Nature, CNN2
         "LoadFromPickle": False, "mutual_info": False,  # Mean or MI
         "hyper_opt_evals": 100, "epoch": 2, "No_0_MI": False,  # True -> Removing 0 MI Features
         "autoencoder": False, "cut": None, "enhanced_dataset": "gan",  # gan, smote, adasyn, ""None""
         "dataset_name": "", "save_images": True, "load_images": False, "save_for_gan":True, "full_dir": "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO/Dataset2Image/dataset/",
        "frac_in_use": 1
         }
#28-36 are 5G-NIDD Full sets
dataset = 35  # change dataset
if dataset == 1: # Binary full datasets #
    train_file = 'CICDDoS2019/label_BENIGN_trainingdata80multiclass.csv'
    test_file = 'CICDDoS2019/label_BENIGN_testingdata20multiclass.csv'
    param["classif_label"] = 'BENIGN'
    param["attack_label"] = 0
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 2:
    train_file = '5G-NIDD BS1/foruse/label_Benign_trainingdata80multiclass.csv'
    test_file = '5G-NIDD BS1/foruse/label_Benign_testingdata20multiclass.csv'
    param["classif_label"] = 'Benign'
    param["attack_label"] = 0
    param["dataset_name"] = "5G-NIDD BS1/foruse/"
elif dataset == 3:
    train_file = "BOT-IoT/label_BENIGN_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_BENIGN_testingdata20multiclass.csv"
    param["classif_label"] = 'Label'
    param["attack_label"] = 0
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 4: #One vs Rest Full Datasets - BOT-IoT datasets #
    train_file = "BOT-IoT/label_DDoS_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_DDoS_testingdata20multiclass.csv"
    param["classif_label"] = "DDoS"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 5:
    train_file = "BOT-IoT/label_DoS Hulk_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_DoS Hulk_testingdata20multiclass.csv"
    param["classif_label"] = "DoS Hulk"
    param["attack_label"] = 1
elif dataset == 6:
    train_file = "BOT-IoT/label_PortScan_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_PortScan_testingdata20multiclass.csv"
    param["classif_label"] = "PortScan"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 7:
    train_file = "BOT-IoT/label_DoS GoldenEye_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_DoS GoldenEye_testingdata20multiclass.csv"
    param["classif_label"] = "DoS GoldenEye"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 8:
    train_file = "BOT-IoT/label_DoS slowloris_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_DoS slowloris_testingdata20multiclass.csv"
    param["classif_label"] = "DoS slowloris"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 9:
    train_file = "BOT-IoT/label_SSH-Patator_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_SSH-Patator_testingdata20multiclass.csv"
    param["classif_label"] = "SSH-Patator"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 10:
    train_file = "BOT-IoT/label_FTP-Patator_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_FTP-Patator_trainingdata20multiclass.csv"
    param["classif_label"] = "FTP-Patator"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 11:
    train_file = "BOT-IoT/label_Web Attack � Brute Force_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_Web Attack � Brute Force_testingdata20multiclass.csv"
    param["classif_label"] = "Web Attack � Brute Force"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 12:
    train_file = "BOT-IoT/label_DoS Slowhttptest_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_DoS Slowhttptest_testingdata20multiclass.csv"
    param["classif_label"] = "DoS Slowhttptest"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 13:
    train_file = "BOT-IoT/label_Web Attack � XSS_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_Web Attack � XSS_testingdata20multiclass.csv"
    param["classif_label"] = "Web Attack � XSS"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 14:
    train_file = "BOT-IoT/label_Bot_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_Bot_testingdata20multiclass.csv"
    param["classif_label"] = "Bot"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 15:
    train_file = "BOT-IoT/label_Web Attack � Sql Injection_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_Web Attack � Sql Injection_testingdata20multiclass.csv"
    param["classif_label"] = "Web Attack � Sql Injection"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 16:
    train_file = "BOT-IoT/label_Infiltration_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_Infiltration_testingdata20multiclass.csv"
    param["classif_label"] = "Infiltration"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 16:
    train_file = "BOT-IoT/label_Heartbleed_trainingdata80multiclass.csv"
    test_file = "BOT-IoT/label_Heartbleed_trainingdata80multiclass.csv"
    param["classif_label"] = "Heartbleed"
    param["attack_label"] = 1
    param["dataset_name"] = "BOT-IoT/"
elif dataset == 17: # 5G-NIDD One vs Rest Full Datasets #
    train_file = "5G-NIDD BS1/foruse/label_Torshammer_trainingdata80multiclass.csv"
    test_file = "5G-NIDD BS1/foruse/label_Torshammer_testingdata20multiclass.csv"
    param["classif_label"] = "Torshammer"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD BS1/foruse/"
elif dataset == 17: 
    train_file = "5G-NIDD BS1/foruse/label_Hping3_trainingdata80multiclass.csv"
    test_file = "5G-NIDD BS1/foruse/label_Hping3_testingdata20multiclass.csv"
    param["classif_label"] = "Hping3"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD BS1/foruse/"
elif dataset == 18:
    train_file = "5G-NIDD BS1/foruse/label_Goldeneye_trainingdata80multiclass.csv"
    test_file = "5G-NIDD BS1/foruse/label_Goldeneye_testingdata20multiclass.csv"
    param["classif_label"] = "Goldeneye"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD BS1/foruse/"
elif dataset == 19:
    train_file = "5G-NIDD BS1/foruse/label_Nmap_trainingdata80multiclass.csv"
    test_file = "5G-NIDD BS1/foruse/label_Nmap_testingdata20multiclass.csv"
    param["classif_label"] = "Nmap"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD BS1/foruse/"
elif dataset == 20:
    train_file = "5G-NIDD BS1/foruse/label_Slowloris_trainingdata80multiclass.csv"
    test_file = "5G-NIDD BS1/foruse/label_Slowloris_testingdata20multiclass.csv"
    param["classif_label"] = "Slowloris"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD BS1/foruse/"
elif dataset == 21: # CICDDos 2019 One vs Rest Full Datasets #
    train_file = "CICDDoS2019/label_NetBIOS_trainingdata80multiclass.csv"
    test_file = "CICDDoS2019/label_NetBIOS_testingdata20multiclass.csv"
    param["classif_label"] = "NetBIOS"
    param["attack_label"] = 1
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 22: 
    train_file = "CICDDoS2019/label_Syn_trainingdata80multiclass.csv"
    test_file = "CICDDoS2019/label_Syn_testingdata20multiclass.csv"
    param["classif_label"] = "Syn"
    param["attack_label"] = 1
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 23: 
    train_file = "CICDDoS2019/label_Portmap_trainingdata80multiclass.csv"
    test_file = "CICDDoS2019/label_Portmap_testingdata20multiclass.csv"
    param["classif_label"] = "Portmap"
    param["attack_label"] = 1
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 24: 
    train_file = "CICDDoS2019/label_UDP_trainingdata80multiclass.csv"
    test_file = "CICDDoS2019/label_UDP_testingdata20multiclass.csv"
    param["classif_label"] = "UDP"
    param["attack_label"] = 1
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 25: 
    train_file = "CICDDoS2019/label_MSSQL_trainingdata80multiclass.csv"
    test_file = "CICDDoS2019/label_MSSQL_testingdata20multiclass.csv"
    param["classif_label"] = "MSSQL"
    param["attack_label"] = 1
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 26: 
    train_file = "CICDDoS2019/label_LDAP_trainingdata80multiclass.csv"
    test_file = "CICDDoS2019/label_LDAP_testingdata20multiclass.csv"
    param["classif_label"] = "LDAP"
    param["attack_label"] = 1
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 27: 
    train_file = "CICDDoS2019/label_UDPLag_trainingdata80multiclass.csv"
    test_file = "CICDDoS2019/label_UDPLag_testingdata20multiclass.csv"
    param["classif_label"] = "UDPLag"
    param["attack_label"] = 1
    param["dataset_name"] = "CICDDoS2019/"
elif dataset == 28:
    train_file = "5G-NIDD Full/label_Benign_trainingdata80multiclass.csv"
    test_file = "5G-NIDD Full/label_Benign_testingdata20multiclass.csv"
    param["classif_label"] = "Benign"
    param["attack_label"] = 0
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 29:
    train_file = "5G-NIDD Full/label_UDPFlood_trainingdata80multiclass.csv"
    test_file = "5G-NIDD Full/label_UDPFlood_testingdata20multiclass.csv"
    param["classif_label"] = "UDPFlood"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 30:
    train_file = "5G-NIDD Full/label_HTTPFlood_trainingdata80multiclass.csv"
    test_file = "5G-NIDD Full/label_HTTPFlood_testingdata20multiclass.csv"
    param["classif_label"] = "HTTPFlood"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 31:
    train_file = "5G-NIDD Full/label_SlowrateDoS_trainingdata80multiclass.csv"
    test_file = "5G-NIDD Full/label_SlowrateDoS_testingdata20multiclass.csv"
    param["classif_label"] = "SlowrateDoS"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 32:
    train_file = "5G-NIDD Full/label_TCPConnectScan_trainingdata80multiclass.csv"
    test_file = "5G-NIDD Full/label_TCPConnectScan_testingdata20multiclass.csv"
    param["classif_label"] = "TCPConnectScan"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 33:
    train_file = "5G-NIDD Full/label_SYNScan_trainingdata80multiclass.csv"
    test_file = "5G-NIDD Full/label_SYNScan_testingdata20multiclass.csv"
    param["classif_label"] = "SYNScan"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 34:
    train_file = "5G-NIDD Full/label_UDPScan_trainingdata80multiclass.csv"
    test_file = "5G-NIDD Full/label_UDPScan_testingdata20multiclass.csv"
    param["classif_label"] = "UDPScan"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 35:
    train_file = "5G-NIDD Full/label_SYNFlood_trainingdata80multiclass.csv"
    test_file = "5G-NIDD Full/label_SYNFlood_testingdata20multiclass.csv"
    param["classif_label"] = "SYNFlood"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 36:
    train_file = "5G-NIDD Full/label_ICMPFlood_trainingdata80multiclass.csv"
    test_file = "5G-NIDD Full/label_ICMPFlood_testingdata20multiclass.csv"
    param["classif_label"] = "ICMPFlood"
    param["attack_label"] = 1
    param["dataset_name"] = "5G-NIDD Full/"
date_stamp = str(datetime.now())
forbidden_characters = [':','/',"\\",'?','<','>','|',"...",".."]
for i in forbidden_characters:
    date_stamp = date_stamp.replace(i, '.')
results_file = param["full_dir"]+param["dataset_name"]+"results/"+param["classif_label"]+"_test_output"+date_stamp+".txt"
sys.stdout = open(results_file,'w')
if not param["LoadFromPickle"]:
    data = {}
    with open(param["full_dir"]+train_file, 'r') as file:
        #data = {"Xtrain": pd.DataFrame(list(csv.DictReader(file)))}#.astype(float), "class": 2}
        data["Xtrain"] = pd.read_csv(file).sample(frac=param["frac_in_use"])
        print("Fraction of dataset in use: "+str(param["frac_in_use"]*100)+"%")
        print("Attack label: "+str(param["classif_label"]))
        #data["Xtrain"].drop(columns=['Unnamed: 0','Unnamed: 0.1'])
        data["Xtrain"].replace(np.nan, 0, inplace=True)
#       data["Xtrain"].dropna(inplace=True)
        print(data["Xtrain"].head())
        print("Number of counts for attack labels: ")
        data["Classification"] = data["Xtrain"][param["classif_label"]]
        del data["Xtrain"][param["classif_label"]]
        f = open(param["full_dir"]+param["dataset_name"]+"Xtrain.pickle",'wb')
        pickle.dump(data["Xtrain"], f)
        f.close()
        f = open(param["full_dir"]+param["dataset_name"]+"Classification.pickle",'wb')
        pickle.dump(data["Classification"],f)
        f.close()
        print(data["Classification"].value_counts())
    with open(param["full_dir"]+test_file, 'r') as file:
        Xtest = pd.read_csv(file).sample(frac=param["frac_in_use"])#pd.DataFrame(list(csv.DictReader(file)))
        #Xtest.drop(columns=['Unnamed: 0','Unnamed: 0.1'])
        Xtest.replace(np.nan, 0, inplace=True)
#       Xtest.dropna(inplace=True)
        print(Xtest.shape)
        data["Xtest"] = Xtest.astype(float)
        data["Ytest"] = data["Xtest"][param["classif_label"]]
        del data["Xtest"][param["classif_label"]]
        print(data["Ytest"].value_counts())
    if param["enhanced_dataset"] == "smote":
        sm = SMOTE(random_state=42)
        data["Xtrain"], data["Classification"] = sm.fit_resample(data["Xtrain"], data["Classification"])
    elif param["enhanced_dataset"] == "adasyn":
        ada = ADASYN(random_state=42)
        data["Xtrain"], data["Classification"] = ada.fit_resample(data["Xtrain"], data["Classification"])

    model = train.train_norm(param, data, norm=False)

else:
    images = {}
    if param['mutual_info']:
        method = 'MI'
    else:
        method = 'Mean'

    if param["enhanced_dataset"] == "gan":
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+'XTrain50A.pickle', 'rb')
        #all_images = pd.DataFrame()
        images["Xtrain"] =pickle.load(f_myfile)
        f_myfile.close()

        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+'YTrain50A.pickle', 'rb')
        images["Classification"] = pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+"TestImages.pickle",'rb')
        images["Xtest"] = pickle.load(f_myfile)
        f_myfile.close()
        
        f_myfile = open(param["dir"] + param['dataset_name'] + param["classif_label"]+"TestLabels.pickle",'rb')
        images["Ytest"] = pickle.load(f_myfile)
        f_myfile.close()

    else:
        f_myfile = open(param["dir"] + 'train_' + str(param['Max_A_Size']) + 'x' + str(
            param['Max_B_Size']) + '_' + method + '.pickle', 'rb')
        images["Xtrain"] = pickle.load(f_myfile)
        f_myfile.close()

        f_myfile = open(param["dir"] + 'YTrain.pickle', 'rb')
        images["Classification"] = pickle.load(f_myfile)
        f_myfile.close()

        f_myfile = open(
            param["dir"] + 'test_' + str(param['Max_A_Size']) + 'x' + str(
                param['Max_B_Size']) + '_' + method + '.pickle',
            'rb')
        images["Xtest"] = pickle.load(f_myfile)
        f_myfile.close()

        f_myfile = open(param["dir"] + 'YTest.pickle', 'rb')
        images["Ytest"] = pickle.load(f_myfile)
        f_myfile.close()

    model = train.train_norm(param, images, norm=False)
    print(model)
    os.system('say "Program finished." ')
# PLOT DATA -- PCA/TSNE
# from sklearn.decomposition import PCA
# from sklearn.manifold import TSNE
# from sklearn.preprocessing import MinMaxScaler
# import matplotlib.pyplot as plt
# pca = TSNE(n_components=2)
# principalComponents = pca.fit_transform(data["Xtrain"])
#
#
# scaler = MinMaxScaler(feature_range=(0, 10))
# scaled_data = scaler.fit_transform(principalComponents)
#
# attacks = np.where(data["Classification"] == 0)
# attacks = scaled_data[attacks[0]]
#
# normals = np.where(data["Classification"] == 1)
# normals = scaled_data[normals[0]]
#
# plt.scatter(attacks[:, 0], attacks[:, 1], color="red", s=1)
#
# plt.scatter(normals[:, 0], normals[:, 1], color="blue", s=1)
#
# plt.show()
# df = pd.DataFrame(scaled_data)
# df["label"] = data["Classification"]
# df.to_csv("AAGM-TSNE_minmax.csv", index=False)
    