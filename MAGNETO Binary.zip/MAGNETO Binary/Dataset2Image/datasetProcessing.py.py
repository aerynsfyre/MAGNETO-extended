#!/usr/bin/env python3

#from table_evaluator import TableEvaluator
import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder, LabelEncoder, MinMaxScaler
from tqdm import tqdm

def create_binary_file(train,test):
	enc = OneHotEncoder()
#	attack_types = ["DoS Hulk","PortScan","DDoS","DDoS Goldeneye","DoS GoldenEye", "FTP-Patator","SSH-Patator","DoS slowloris","DoS Slowhttptest","Bot","Web Attack � Brute Force", "Web Attack � XSS", "Infiltration", "Web Attack � Sql Injection","Heartbleed"]
	toEncode = ['SrcMac', 'DstMac', 'Sport', 'Dport','StartTime','LastTime','TcpOpt', 'Attack Type', 'sVlan', 'dVlan', 'State', 'Dir', 'Cause', 'sIpId', 'dIpId', 'sDSb', 'dDSb', 'SrcAddr', 'DstAddr', 'Flgs', 'SrcId']
	train[toEncode] = enc.fit_transform(train[toEncode])
	train["Label"].replace("Malicious", 1, inplace=True)
	train["Label"].replace("Benign", 0, inplace=True)
	test["Label"].replace("Malicious", 1, inplace=True)
	test["Label"].replace("Benign", 0, inplace=True)
#	
#	enc = LabelEncoder()
#	train['Label'] = enc.fit_transform(train["Label"])
#	test['Label'] = enc.transform(test["Label"])
	print(train['Label'].value_counts())
	train = train.drop(columns=['Proto','Attack Tool'])
	test = test.drop(columns=['Proto','Attack Tool'])
#	train.drop(columns = columnsToDrop, inplace=True, errors='ignore')
#	test.drop(columns = columnsToDrop, inplace=True, errors='ignore')
	train.replace([np.inf, -np.inf], np.nan, inplace=True)
	test.replace([np.inf, -np.inf], np.nan, inplace=True)
	train.dropna(axis=1, how='all',inplace=True)
	test.dropna(axis=1, how='all',inplace=True)
	numerical_columns = train.columns
	scaler = MinMaxScaler()
	train[numerical_columns] = scaler.fit_transform(train[numerical_columns])
	test[numerical_columns] = scaler.transform(test[numerical_columns])
	return train,test

def create_multiclass_file(train, test, train_file, test_file, dirname):
	enc = OneHotEncoder()
	label_columns = train["Label"].unique()
	labels_train = pd.DataFrame()
	labels_test = pd.DataFrame()
	labels_train = pd.get_dummies(train["Label"])#enc.fit_transform(train["Label"].shape(-1,1))
	labels_test = pd.get_dummies(test["Label"])#enc.transform(test["Label"].shape(-1,1))
	labels = list(labels_train.columns.values).str.replace('\W', '', regex=True)
	print(labels_train.head())
	print(labels_train.value_counts())
	train.drop(columns=["Label"], inplace=True)
	test.drop(columns=["Label"], inplace=True)
#	train = train.drop(columns=['Protocol'])#,'Attack Tool','Label'
#	test = test.drop(columns=['Protocol'])#,'Attack Tool', 'Label'
#	train.drop(columns = columnsToDrop, inplace=True, errors='ignore')
#	test.drop(columns = columnsToDrop, inplace=True, errors='ignore')
	train.replace([np.inf, -np.inf], np.nan, inplace=True)
	test.replace([np.inf, -np.inf], np.nan, inplace=True)
	train.dropna(axis=1, how='all',inplace=True)
	test.dropna(axis=1, how='all',inplace=True)
	numerical_columns = train.columns
	scaler = MinMaxScaler()
	train[numerical_columns] = scaler.fit_transform(train[numerical_columns])
	test[numerical_columns] = scaler.transform(test[numerical_columns])
	t = pd.DataFrame()
	for i in tqdm(labels):
		train_export = train.join(labels_train[i]).str.replace('\W', '', regex=True)
		test_export = test.join(labels_test[i]).str.replace('\W', '', regex=True)
		train_export.to_csv(dirname+"label_"+str(i.str.replace('\W', '', regex=True))+"_"+train_file)
		test_export.to_csv(dirname+"label_"+str(i.str.replace('\W', '', regex=True))+"_"+test_file)
		print(train_export.head())
#		train.drop(columns=[i], inplace=True)
#		test.drop(columns=[i], inplace=True)
	return train,test
	
def save_files(train,test,train_file,test_file):
	print(train.head())
	print(train.info(verbose=True, show_counts=True))
	print(test.head())
	print(test.info(verbose=True, show_counts=True))
	train.to_csv(train_file)
	test.to_csv(test_file)
	
	
	
dirname = "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO/Dataset2Image/dataset/BOT-IoT/"
#load the training and testing files. 
trainFile = dirname+"training80.csv"#"Automotive_Ethernet_with_Attack_original_10_17_19_50_training.pcap"
testFile = dirname+"testing20.csv"#"Automotive_Ethernet_with_Attack_original_10_17_20_04_test.pcap"
train = pd.DataFrame(pd.read_csv(trainFile, on_bad_lines='skip'))
test = pd.DataFrame(pd.read_csv(testFile,  on_bad_lines='skip'))
print(train.info(verbose=True, show_counts=True))
print("################")
print(train.head())
print("################")
#print(train.Label.value_counts())
#print("################")
#print(test.Label.value_counts())
#print("################")

##Label whether the attacks are Reflection-Based or Exploitation-Based.
#train["Label"].replace({'DrDoS_UDP':'UDP', 'DrDoS_LDAP':'LDAP', 'DrDoS_MSSQL':'MSSQL', 
#	'DrDoS_NetBIOS':'NetBIOS','DrDoS_DNS':'DNS', 'DrDoS_NTP':'NTP', 
#	'DrDoS_SSDP':'SSDP', 'DrDoS_SNMP':'SNMP', 'UDP-lag':'UDPLag'}, inplace = True)
#test["Label"].replace({'DrDoS_UDP':'UDP', 'DrDoS_LDAP':'LDAP', 'DrDoS_MSSQL':'MSSQL', 
#	'DrDoS_NetBIOS':'NetBIOS','DrDoS_DNS':'DNS', 'DrDoS_NTP':'NTP', 
#	'DrDoS_SSDP':'SSDP', 'DrDoS_SNMP':'SNMP', 'UDP-lag':'UDPLag'}, inplace = True)
#
#reflection_list = ['MSSQL', 'NetBIOS', 'LDAP', 'SSDP', 'TFTP', 'NTP', 'SNMP', 'WebDDoS', 'DNS', 'Portmap']
#exploitation_list = ['Syn', 'UDP', 'UDPLag']
#
#train["Label"].replace(reflection_list, ["RAS"]*len(reflection_list), inplace=True) #RAS = 1
#test["Label"].replace(reflection_list, ["RAS"]*len(reflection_list), inplace=True) #RAS =1
#train["Label"].replace(exploitation_list, ["EAS"]*len(exploitation_list), inplace=True) #EAS=2
#test["Label"].replace(exploitation_list, ["EAS"]*len(exploitation_list), inplace=True) #EAS=2
#train["Label"].replace("BENIGN", 0, inplace=True) #Benign=0
#test["Label"].replace("BENIGN", 0, inplace=True) #Benign=0


#print(train.Label.value_counts())
#print("################")
#print(test.Label.value_counts())
#print("################")

#drop unnecessary columns:
train.columns = train.columns.str.strip()
test.columns = test.columns.str.strip()
#columnsToDrop = ['Unnamed: 0','SrcMac', 'DstMac', 'Sport', 'Dport','StartTime','LastTime','TcpOpt', 'Attack Type', 'sVlan', 'dVlan', 'State', 'Dir', 'Cause', 'sIpId', 'dIpId', 'sDSb', 'dDSb', 'SrcAddr', 'DstAddr', 'Flgs', 'SrcId'] #5g-NIDD columns to drop  'Attack Type'
#columnsToDrop = ['Unnamed: 0','Unnamed: 0.1','Unnamed: 0.2', 'Flow ID', 'Source IP', 'Source Port', 'Destination IP', 'Destination Port', 'Timestamp', 'SimillarHTTP'] #CICDDoS19 columns to drop.

print(train["Label"].value_counts())
print("################")
print(train.info(verbose='True'))
print("################")
print("Training Data Shape: ", train.shape)
print("################")
print("Testing Data Shape: ", test.shape)

train,test = create_multiclass_file(train,test,"trainingdata80multiclass.csv","testingdata20multiclass.csv",dirname)
#save_files(train,test,"trainingdata80multiclass.csv","testingdata20multiclass.csv")

