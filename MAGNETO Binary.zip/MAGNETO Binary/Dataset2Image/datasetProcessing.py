#!/usr/bin/env python3
# Code from Dunmore et al., 2023, "MAGNETO and DeepInsight: Extended Image Translation with Semantic Relationships for Classifying Attack Data with Machine Learning Models".
# Please cite this paper if you are going to use any part of this code in further research.

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import OneHotEncoder, LabelEncoder, MinMaxScaler
from tqdm import tqdm

def create_binary_file(train,test,label,attack_label, train_file, test_file, dirname):
	enc = OneHotEncoder()
	train[label].replace(attack_label, 0, inplace=True)
	train.loc[train[label]!=0] = 1
	test[label].replace(attack_label, 0, inplace=True)
	test.loc[test[label]!=0] = 1

	train_labels = enc.transform(train[label])
	test_labels = enc.transform(test[label])

	train.replace([np.inf, -np.inf], np.nan, inplace=True)
	test.replace([np.inf, -np.inf], np.nan, inplace=True)
	train.dropna(axis=1, how='all',inplace=True)
	test.dropna(axis=1, how='all',inplace=True)

	train = train.select_dtypes(['number'])
	test = test.select_dtypes(['number'])
	numerical_columns = train.columns
	scaler = MinMaxScaler()
	train[numerical_columns] = scaler.fit_transform(train[numerical_columns])
	test[numerical_columns] = scaler.transform(test[numerical_columns])
	train["Label"] = train_labels
	test["Label"] = test_labels
	return train,test

def create_multiclass_file(train, test, label, train_file, test_file, dirname):
	enc = OneHotEncoder()
	train.dropna()
	test.dropna()
	print("Training Label Counts: ")
	print(train[label].head())
	
	print("Testing Label Counts: ")
	print(test[label].head())

	print("Training Label Counts: ")
	train[label].dropna()
	train_label = train[label][train[label] != "nan"]
	print(train[label].value_counts())
	
	print("Testing Label Counts: ")
	test[label].dropna()
	test_label = test[label][test[label] != "nan"]
	print(test_label.value_counts())
	print(test_label.head())
	all_labels = pd.concat([train_label,test_label], axis=0)
	print("Total labels:")
	print(all_labels.value_counts())
	print("###############")
	labels_train = pd.DataFrame(train_label.value_counts())
	labels_test = pd.DataFrame(test_label.value_counts())

	enc = LabelEncoder()
	unique_labels = pd.concat([test_label,train_label],axis=0)
	print("Counts for training and testing labels:")
	print(unique_labels.value_counts())
	print("################")

	unique_labels = unique_labels.reset_index()
	
	unique_labels.reset_index(drop=True)
	print("Unique labels and totals for training and testing sets: ")
	print(unique_labels[label].value_counts())
	print("#########################+++++++")

	labels_only = np.asarray((unique_labels[label]))
	print(labels_only[:10])
	print("##############")

	enc = LabelEncoder()
	labels_only = enc.fit_transform(labels_only)
	print(labels_only[:10])
	train_multi = enc.transform(train_label)
	test_multi = enc.transform(test_label)

	train.drop(columns=[label], inplace=True)
	test.drop(columns=[label], inplace=True)

	train.replace([np.inf, -np.inf], np.nan, inplace=True)
	test.replace([np.inf, -np.inf], np.nan, inplace=True)
	train.dropna(axis=1, how='all',inplace=True)
	test.dropna(axis=1, how='all',inplace=True)
	
	train = train.select_dtypes(['number'])
	test = test.select_dtypes(['number'])
	numerical_columns = train.columns.values
	scaler = MinMaxScaler()
	train[numerical_columns] = scaler.fit_transform(train[numerical_columns])
	test[numerical_columns] = scaler.transform(test[numerical_columns])
	t = pd.DataFrame()
	train["Label"] = train_multi
	test["Label"] = test_multi
	return train,test
	
def save_files(train,test,train_file,test_file,dirname):
	print(train.head())
	print(train.info(verbose=True, show_counts=True))
	print(test.head())
	print(test.info(verbose=True, show_counts=True))
	train.to_csv(dirname+train_file)
	test.to_csv(dirname+test_file)
	
	
	
dirname = "//Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO datasets/CICIDS17/"
#load the training and testing files. 
trainFile = dirname+"training80.csv"
testFile = dirname+"testing20.csv"
train = pd.DataFrame(pd.read_csv(trainFile, on_bad_lines='skip'))
test = pd.DataFrame(pd.read_csv(testFile,  on_bad_lines='skip'))

label = "type"
benign_label = "normal"
test_file = "testing20multiclass10percent.csv"
train_file = "training80multiclass10percent.csv"

# if there is an existing label column. If not, comment out.
train.drop(columns=["label"], axis=1,inplace=True)
test.drop(columns=["label"], axis=1,inplace=True)

print(train.info(verbose=True, show_counts=True))
print("################")
print(train.head())
print("################")
print("Current train file:")
print(train.head())
print("###############")

#drop unnecessary columns:
train.columns = train.columns.str.strip()
test.columns = test.columns.str.strip()

print(train[label].value_counts())
print("################")
print(test[label].value_counts())
print("################")
print(train.info(verbose='True'))
print("################")
print("Training Data Shape: ", train.shape)
print("################")
print("Testing Data Shape: ", test.shape)

train,test = create_multiclass_file(train,test,label,train_file,test_file,dirname)
save_files(train,test,train_file,test_file,dirname)

