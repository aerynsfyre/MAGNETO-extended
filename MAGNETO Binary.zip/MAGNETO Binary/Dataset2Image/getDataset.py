#!/usr/bin/env python3

#Go through the datasets provided in CICIDS2017 and create two files: train.csv and test.csv, containing both Benign and Attack samples.
import os
import numpy
import pandas as pd
from sklearn.model_selection import train_test_split
from tqdm import tqdm, trange

datasetPath = "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO/Dataset2Image/dataset/Automotive Ethernet Dataset/"
train_csvs = []
for dirname, _, filenames in os.walk(datasetPath):
	for filename in filenames:
		if ".csv" in filename:
			train_csvs.append(os.path.join(dirname, filename))
print(train_csvs)			
#datasetPath = "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO/Dataset2Image/dataset/CICDDoS2019/03-11/"
#train_csvs = []
#for dirname, _, filenames in os.walk(datasetPath):
#	for filename in filenames:
#		if ".csv" in filename:
#			train_csvs.append(os.path.join(dirname, filename))
#print(train_csvs)	
input = []
print("Importing files...")
for i in (train_csvs):
	inputFile = open(i)
	input.append(pd.DataFrame(pd.read_csv(inputFile)))
input = pd.concat(input)
print(input.head())
outputFileNameTrain = "dataset/Automotive Ethernet Dataset/training80.csv"
outputFileNameTest = "dataset/Automotive Ethernet Dataset/testing20.csv"
inputFile.close()
#Get the total number of rows.
inputLen = len(input)
print("Input file size: ",inputLen)
#Training set is 80% of the original set.
trainingSize = int((inputLen/100)*80)
i = 0
testingSize = inputLen-trainingSize
print("Testing file size: ",testingSize)
print("Training file size: ", trainingSize)
sample = input.sample(frac = 0.5)
outputTrain = pd.DataFrame()
outputTest = pd.DataFrame()
i = 0
print("Creating Training File (90% of total file size, chosen randomly)...")
outputTrain,outputTest = train_test_split(input, test_size=0.2)
outputTrain.to_csv(outputFileNameTrain)
print(outputTrain.head())
print("\nTraining file created.")

i = 0
print("Creating Testing File (10% of total file size, chosen randomly)...")
outputTest.to_csv(outputFileNameTest)
print(outputTest.head())
print("\nTesting file created.")
del input, outputTest, outputTrain
print("Operation complete.")