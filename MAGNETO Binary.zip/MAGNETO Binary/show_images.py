#!/usr/bin/env python3
import numpy as np
import math
import matplotlib.pyplot as plt
import os
import sys
import pickle
import pandas as pd
import csv
from keras.utils import to_categorical
from PIL import Image, ImageDraw

def generate_grid(images, labels, indexes, params):
	random_images = {}
	image = pd.DataFrame()
	label = np.argmax(labels,axis=1)
	#labels = np.argmax(labels,axis=1)
	file_name = params["full_dir"]+params["dataset_name"]+"Images"
	x=0
	plt.figure(figsize=(2.2, 2.2))
	rows = int(math.sqrt(len(indexes)))
	font_dict = {'color': 'black',
		'verticalalignment': 'top',
		'horizontalalignment': 'center'
	}
	for i in indexes:
		if x < (len(indexes)-1):
			ax = plt.subplot(rows, rows, x+1)
			temp = (np.reshape(images[i],[params["Max_A_Size"],-1]))
			filename = (file_name+"/"+str(indexes[x])+".png")
			print(filename)
			os.makedirs(file_name, exist_ok=True)
			img = Image.fromarray((temp),'P')
			img.resize((params["Max_A_Size"]*100,params["Max_B_Size"]*100))
			current_position = ax.set_title(str(label[i]),size='xx-small',weight='bold',fontdict=font_dict)
			plt.imshow(img)
			plt.axis('off')
			x=x+1
	plt.savefig(filename)

param = {"Max_A_Size": 10, "Max_B_Size": 10, "Dynamic_Size": False, 'Metod': 'tSNE', "ValidRatio": 0.1, "seed": 180,
	"dir": "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO/Dataset2Image/dataset/", "Mode": "CNN2",  # Mode : CNN_Nature, CNN2
	"LoadFromPickle": True, "mutual_info": False,  # Mean or MI
	"hyper_opt_evals": 100, "epoch": 2, "No_0_MI": False,  # True -> Removing 0 MI Features
	"autoencoder": False, "cut": None, "enhanced_dataset": "gan",  # gan, smote, adasyn, ""None""
	"dataset_name": "", "full_dir": "/Users/spacebug/Library/CloudStorage/OneDrive-Personal/Uni/Research/Current/MAGNETO for Network Traffic IDS with Image Translation/MAGNETO/Dataset2Image/dataset/",
	"frac_in_use": 1
}
dataset = 3  # change dataset
image_size = str(param["Max_A_Size"])
if dataset == 1: #Multi class labels
	param["classif_label"] = 'Label'
	param["attack_label"] = 0
	param["outputs"] = 8
	param["dataset_name"] = "CICDDoS2019/"
elif dataset == 2:
	param["classif_label"] = 'Attack Type'
	param["attack_label"] = 1.0
	param["outputs"] = 9
	param["dataset_name"] = "5G-NIDD Full/"
elif dataset == 3:
	param["classif_label"] = 'Label'
	param["attack_label"] = 1.0
	param["outputs"] = 15
	param["dataset_name"] = "BOT-IoT/"
dataset = {}	
f_myfile = open(param["full_dir"]+param['dataset_name']+'MulticlassGANImages.pickle', 'rb')
#all_images = pd.DataFrame()
dataset["Xtrain"] =pickle.load(f_myfile)
f_myfile.close()

f_myfile = open(param["full_dir"]+param['dataset_name']+'MulticlassGANLabels.pickle', 'rb')
dataset["Classification"] = pickle.load(f_myfile)
f_myfile.close()

#f = open(param["full_dir"]+param["dataset_name"]+"MulticlassTrainImages.pickle",'rb')
#dataset["Xtrain"] = pickle.load(f)
#f.close()
#f = open(param["full_dir"]+param["dataset_name"]+"MulticlassTrainLabels.pickle",'rb')
#dataset["Classification"] = pickle.load(f)
#f.close()
dataset["Xtrain"] = np.reshape(dataset["Xtrain"], [-1, param["Max_A_Size"], param["Max_B_Size"],1])
dataset["Classification"] = to_categorical(dataset["Classification"])
print("Image shape: "+str(dataset["Xtrain"].shape))
print("Label shape: "+str(dataset["Classification"].shape))
batch_size = 10
for i in range(batch_size):
	random_indexes = np.random.randint(0,len(dataset["Classification"]),size=10)
	#plot_images(dataset["Xtrain"], dataset["Classification"], random_indexes, param)
	generate_grid(dataset["Xtrain"], dataset["Classification"], random_indexes, param)
	#create_images(image_grid, random_indexes,param)